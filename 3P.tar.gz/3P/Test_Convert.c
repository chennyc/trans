#include <stdio.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <string.h>
#include <stdint.h>  
#include <sys/wait.h>
#include <sys/time.h>
#include <gmp.h> 
#include <wmmintrin.h>
#include <tmmintrin.h>
#include "floram_util.h"

uint8_t * ciphertext_1;
uint8_t * ciphertext_2;
uint8_t * ciphertext_3;
uint8_t * ciphertext_4;

void prg_aes_ni_quad(uint64_t * keyed_a, __uint128_t * alpha_1, __uint128_t * alpha_2, __uint128_t * alpha_3, __uint128_t * alpha_4, uint8_t * plaintext_1, uint8_t * plaintext_2, uint8_t * plaintext_3, uint8_t * plaintext_4)
{
//uint8_t * plaintext_prg = malloc(16); //This should be set as a global value
//	printf("this is prg\n");
	offline_prg(ciphertext_1, plaintext_1, keyed_a);
//	printf("this is prg\n");
	offline_prg(ciphertext_2, plaintext_2, keyed_a);
	offline_prg(ciphertext_3, plaintext_3, keyed_a);
	offline_prg(ciphertext_4, plaintext_4, keyed_a);
//	memcpy(plaintext_prg,ciphertext_prg,16*sizeof(uint8_t));

	memcpy(alpha_1,ciphertext_1,16*sizeof(uint8_t));
	memcpy(alpha_2,ciphertext_2,16*sizeof(uint8_t));
	memcpy(alpha_3,ciphertext_3,16*sizeof(uint8_t));
	memcpy(alpha_4,ciphertext_4,16*sizeof(uint8_t));
//	printf("this is prg\n");
	//mpz_mod (alpha, alpha, d);
}

void convert_bit(int index, mpz_t * mpz_array, int ell)
{
	
	char bits[ell];
	int i;
	for(i = 0; i< ell; i++)
	{
		//strcpy(bits[i], 'a');
		bits[i] = 'a';
	}

	mpz_t storage;
	mpz_init (storage);
	mpz_set_ui(storage, index);
	mpz_get_str(bits, 2, storage);
	int tmp;
	for(i = ell - 1; i>=0; i--)
	{
		if(bits[i]=='a')
		{
			//strcpy(bits[i], '0');	
			bits[i] = '0';
		}
		else if((bits[i]!='1')&&(bits[i]!='0'))bits[i] = '0';
		
		tmp = bits[i] - '0';
		mpz_set_ui(mpz_array[ell-1-i], tmp);
		//printf("i[%d]:%d\n", i, tmp);

	}
	mpz_clear (storage);

}

mpz_t* Init_one (int num){

	int i;
	mpz_t * op=(mpz_t*)malloc(sizeof(mpz_t) * num);
	for(i = 0; i < num; i++)
      	mpz_init(op[i]);
	return op;
}
void test_spped_set()
{
	int i;
	uint8_t plain[]      = {0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34};
	uint8_t cipher[]     = {0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb, 0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32};
	mpz_t a, b, c;
	mpz_init(a);
	mpz_init(b);
	mpz_init(c);
	mpz_import(a, 16, 1, sizeof(uint8_t), 0, 0, plain);
	mpz_import(b, 16, 1, sizeof(uint8_t), 0, 0, cipher);
	mpz_import(c, 16, 1, sizeof(uint8_t), 0, 0, cipher);

	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here



	for(i =0; i<1024000;i++)
	{
		mpz_set(a, b);
	}

	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("set = %ld us\n",timer1);

	mpz_clear(a);
	mpz_clear(b);
	mpz_clear(c);
}

void test_spped_mod()
{
	int i;
	uint8_t plain[]      = {0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34};
	uint8_t cipher[]     = {0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb, 0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32};
	mpz_t a, b, c;
	mpz_init(a);
	mpz_init(b);
	mpz_init(c);
	mpz_import(a, 16, 1, sizeof(uint8_t), 0, 0, plain);
	mpz_import(b, 16, 1, sizeof(uint8_t), 0, 0, cipher);
	mpz_import(c, 16, 1, sizeof(uint8_t), 0, 0, cipher);

	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here


	for(i =0; i<1024000;i++)
	{
		mpz_mod(c, a, b);
	}
	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("mod = %ld us\n",timer1);


	mpz_clear(a);
	mpz_clear(b);
	mpz_clear(c);
}

void test_spped_add()
{
	int i;
	uint8_t plain[]      = {0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34};
	uint8_t cipher[]     = {0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb, 0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32};
	mpz_t a, b, c;
	mpz_init(a);
	mpz_init(b);
	mpz_init(c);
	mpz_import(a, 16, 1, sizeof(uint8_t), 0, 0, plain);
	mpz_import(b, 16, 1, sizeof(uint8_t), 0, 0, cipher);
	mpz_import(c, 16, 1, sizeof(uint8_t), 0, 0, cipher);

	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here


	for(i =0; i<1024000;i++)
	{
		mpz_add(a, a, b);
		//mpz_mod(a, a, b);
	}

	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("add = %ld us\n",timer1);


	mpz_clear(a);
	mpz_clear(b);
	mpz_clear(c);
}

void test_spped_mul()
{
	int i;
	uint8_t plain[]      = {0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34};
	uint8_t cipher[]     = {0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb, 0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32};
	mpz_t a, b, c;
	mpz_init(a);
	mpz_init(b);
	mpz_init(c);
	mpz_import(a, 16, 1, sizeof(uint8_t), 0, 0, plain);
	mpz_import(b, 16, 1, sizeof(uint8_t), 0, 0, cipher);
	mpz_import(c, 16, 1, sizeof(uint8_t), 0, 0, cipher);
	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here


	for(i =0; i<1024000;i++)
	{
		mpz_mul(a, a, b);
		mpz_mod(a, a, c);
	}

	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("mul+mod  =%ld us\n",timer1);


	mpz_clear(a);
	mpz_clear(b);
	mpz_clear(c);
}


void test_spped_addmul()
{
	int i;
	uint8_t plain[]      = {0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34};
	uint8_t cipher[]     = {0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb, 0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32};
	uint8_t cc[]     = {0x29, 0x23, 0x84, 0x1d, 0x12, 0x2c, 0x39, 0x3b, 0xdc, 0x21, 0x15, 0x37, 0x29, 0x6f, 0x0b, 0x32};
	mpz_t a, b, c;
	mpz_init(a);
	mpz_init(b);
	mpz_init(c);
	mpz_import(a, 16, 1, sizeof(uint8_t), 0, 0, plain);
	mpz_import(b, 16, 1, sizeof(uint8_t), 0, 0, cipher);
	mpz_import(c, 16, 1, sizeof(uint8_t), 0, 0, cc);
	//#pragma omp parallel for num_threads(16)

	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here


	for(i =0; i<1024000;i++)
	{
		mpz_addmul(a, a, b);
		mpz_mod(a, a, c);
	}


	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("addmul+ mod  =%ld us\n",timer1);


	mpz_clear(a);
	mpz_clear(b);
	mpz_clear(c);
}

void test_spped_add_mul()
{
	int i;
	uint8_t plain[]      = {0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34};
	uint8_t cipher[]     = {0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb, 0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32};
	mpz_t a, b, c;
	mpz_init(a);
	mpz_init(b);
	mpz_init(c);
	mpz_import(a, 16, 1, sizeof(uint8_t), 0, 0, plain);
	mpz_import(b, 16, 1, sizeof(uint8_t), 0, 0, cipher);
	mpz_import(c, 16, 1, sizeof(uint8_t), 0, 0, cipher);


	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here

	for(i =0; i<1024000;i++)
	{
		mpz_add(a, a, b);
		mpz_mul(a, a, b);
		mpz_mod(a, a, c);
	}

	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("add+mul+mod  =%ld us\n",timer1);


	mpz_clear(a);
	mpz_clear(b);
	mpz_clear(c);
}

void test_spped_init_clear()
{
	int i;

	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here

	//#pragma omp parallel for num_threads(16)
	for(i =0; i<1024000;i++)
	{
	mpz_t a;
	mpz_init(a);
	mpz_clear(a);

	}

	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("init+clear  =%ld us\n",timer1);
}

void test_spped_basic()
{
	int i;

	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here

	//#pragma omp parallel for num_threads(16)
	for(i =0; i<1024000;i++)
	{


	}

	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("basic  =%ld us\n",timer1);
}

void test_spped_malloc_free()
{
	int i;

	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here

	//#pragma omp parallel for num_threads(16)
	for(i =0; i<1024000;i++)
	{
	uint8_t * plaintext_1 = malloc(16);
	free(plaintext_1);
	}

	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("malloc_free  =%ld us\n",timer1);
}




void prg_aes_ni_quad_import_str(mpz_t alpha_1, mpz_t alpha_2, mpz_t alpha_3, mpz_t alpha_4, mpz_t tmp, uint64_t * keyed_a, uint8_t * plaintext_1, uint8_t * plaintext_2, uint8_t * plaintext_3, uint8_t * plaintext_4)
{
  //uint8_t * plaintext_prg = malloc(16); //This should be set as a global value
  //printf("this is prg\n");	
int i; 
  offline_prg(ciphertext_1, plaintext_1, keyed_a);
  //printf("this is prg\n");
  offline_prg(ciphertext_2, plaintext_2, keyed_a);
  offline_prg(ciphertext_3, plaintext_3, keyed_a);
  offline_prg(ciphertext_4, plaintext_4, keyed_a);

long * a = (long *)ciphertext_1;
long * b = (long *)ciphertext_1;
long * c = (long *)ciphertext_1;
long * d = (long *)ciphertext_1;
/*
for(i = 0; i < sizeof(*a);i++)
{
a[i]=abs(a[i]);
}
*/
//char array[16];
//memcpy(array, a, 16);
//printf("this is the array ; %s\n", array);
//printf("size of long long ; %d\n", sizeof(long long));
//printf("size of long ; %d\n", sizeof(long));

mpz_set_ui(alpha_1, a[1]);
mpz_set_ui(tmp, a[0]);
//mpz_addmul_si(alpha_1, alpha_2, 100000000);
//mpz_mul_2exp(tmp, tmp, 64);
//mpz_add(alpha_1, alpha_1, tmp);
mpz_addmul_ui(alpha_1, tmp, 10000000000);

mpz_set_ui(alpha_1, b[1]);
mpz_set_ui(tmp, b[0]);
//mpz_addmul_si(alpha_1, alpha_2, 100000000);
//mpz_mul_2exp(tmp, tmp, 64);
//mpz_add(alpha_2, alpha_2, tmp);
mpz_addmul_ui(alpha_2, tmp, 10000000000);

mpz_set_ui(alpha_1, c[1]);
mpz_set_ui(tmp, c[0]);
//mpz_addmul_si(alpha_1, alpha_2, 100000000);
//mpz_mul_2exp(tmp, tmp, 64);
//mpz_add(alpha_3, alpha_3, tmp);
mpz_addmul_ui(alpha_3, tmp, 10000000000);

mpz_set_ui(alpha_1, d[1]);
mpz_set_ui(tmp, d[0]);
mpz_addmul_ui(alpha_4, tmp, 10000000000);
//mpz_addmul_si(alpha_1, alpha_2, 100000000);
//mpz_mul_2exp(tmp, tmp, 64);
//mpz_add(alpha_4, alpha_4, tmp);
//snprintf(array,40,"%d%d%d%d",a[0],a[1],a[2],a[3]);
/*
char array1[10];
itoa(a[1],array1,10);
char array2[10];
itoa(a[2],array2,10);
char array3[10];
itoa(a[3],array3,10);
char array_f[40];
strcpy(array_f, array);
strcat(array_f, array1);
strcat(array_f, array2);
strcat(array_f, array3);



  mpz_import(alpha_1, 16, 1, sizeof(*ciphertext_1), 0, 0, ciphertext_1);
  mpz_import(alpha_2, 16, 1, sizeof(*ciphertext_2), 0, 0, ciphertext_2);
  mpz_import(alpha_3, 16, 1, sizeof(*ciphertext_3), 0, 0, ciphertext_3);
  mpz_import(alpha_4, 16, 1, sizeof(*ciphertext_4), 0, 0, ciphertext_4);
*/
  //mpz_mod (alpha, alpha, d);
  //gmp_sscanf(ciphertext_1, alpha_1);

//i = mpz_set_str(alpha_1, array, 10);
//printf("this is the r ; %d", i);
// mpz_set_str(alpha_2, array, 10);
// mpz_set_str(alpha_3, array, 10);
// mpz_set_str(alpha_4, array, 10);
 //mpz_set_str(alpha_1, array, 10);
 // mpz_set_str(alpha_2, ciphertext_2, 10);
 // mpz_set_str(alpha_3, ciphertext_3, 10);
 // mpz_set_str(alpha_4, ciphertext_4, 10);

}

void prg_aes_ni_quad_import(mpz_t alpha_1, mpz_t alpha_2, mpz_t alpha_3, mpz_t alpha_4, mpz_t tmp, uint64_t * keyed_a, uint8_t * plaintext_1, uint8_t * plaintext_2, uint8_t * plaintext_3, uint8_t * plaintext_4)
{
  //uint8_t * plaintext_prg = malloc(16); //This should be set as a global value
  //printf("this is prg\n");	
int i; 
  offline_prg(ciphertext_1, plaintext_1, keyed_a);
  //printf("this is prg\n");
  offline_prg(ciphertext_2, plaintext_2, keyed_a);
  offline_prg(ciphertext_3, plaintext_3, keyed_a);
  offline_prg(ciphertext_4, plaintext_4, keyed_a);

  mpz_import(alpha_1, 16, 1, sizeof(uint8_t), 0, 0, ciphertext_1);
  mpz_import(alpha_2, 16, 1, sizeof(uint8_t), 0, 0, ciphertext_2);
  mpz_import(alpha_3, 16, 1, sizeof(uint8_t), 0, 0, ciphertext_3);
  mpz_import(alpha_4, 16, 1, sizeof(uint8_t), 0, 0, ciphertext_4);

  //mpz_mod (alpha, alpha, d);
  //gmp_sscanf(ciphertext_1, alpha_1);

//i = mpz_set_str(alpha_1, array, 10);
//printf("this is the r ; %d", i);
// mpz_set_str(alpha_2, array, 10);
// mpz_set_str(alpha_3, array, 10);
// mpz_set_str(alpha_4, array, 10);
 //mpz_set_str(alpha_1, array, 10);
 // mpz_set_str(alpha_2, ciphertext_2, 10);
 // mpz_set_str(alpha_3, ciphertext_3, 10);
 // mpz_set_str(alpha_4, ciphertext_4, 10);

}

void prg_aes_ni_quad_export(mpz_t alpha_1, mpz_t alpha_2, mpz_t alpha_3, mpz_t alpha_4, mpz_t tmp, uint64_t * keyed_a, uint8_t * plaintext_1, uint8_t * plaintext_2, uint8_t * plaintext_3, uint8_t * plaintext_4)
{
  //uint8_t * plaintext_prg = malloc(16); //This should be set as a global value
  //printf("this is prg\n");	
int i; 
  offline_prg(ciphertext_1, plaintext_1, keyed_a);
  //printf("this is prg\n");
  offline_prg(ciphertext_2, plaintext_2, keyed_a);
  offline_prg(ciphertext_3, plaintext_3, keyed_a);
  offline_prg(ciphertext_4, plaintext_4, keyed_a);


//mpz_mul_2exp(tmp, tmp, 64);
//mpz_add(alpha_4, alpha_4, tmp);
//snprintf(array,40,"%d%d%d%d",a[0],a[1],a[2],a[3]);
/*
char array1[10];
itoa(a[1],array1,10);
char array2[10];
itoa(a[2],array2,10);
char array3[10];
itoa(a[3],array3,10);
char array_f[40];
strcpy(array_f, array);
strcat(array_f, array1);
strcat(array_f, array2);
strcat(array_f, array3);
*/


  mpz_import(alpha_1, 16, 1, sizeof(*ciphertext_1), 0, 0, ciphertext_1);
  mpz_import(alpha_2, 16, 1, sizeof(*ciphertext_2), 0, 0, ciphertext_2);
  mpz_import(alpha_3, 16, 1, sizeof(*ciphertext_3), 0, 0, ciphertext_3);
  mpz_import(alpha_4, 16, 1, sizeof(*ciphertext_4), 0, 0, ciphertext_4);
  mpz_export(plaintext_1, NULL, 1, sizeof(*plaintext_1), 0, 0, alpha_1);
  //mpz_mod (alpha, alpha, d);
  //gmp_sscanf(ciphertext_1, alpha_1);

//i = mpz_set_str(alpha_1, array, 10);
//printf("this is the r ; %d", i);
// mpz_set_str(alpha_2, array, 10);
// mpz_set_str(alpha_3, array, 10);
// mpz_set_str(alpha_4, array, 10);
 //mpz_set_str(alpha_1, array, 10);
 // mpz_set_str(alpha_2, ciphertext_2, 10);
 // mpz_set_str(alpha_3, ciphertext_3, 10);
 // mpz_set_str(alpha_4, ciphertext_4, 10);

}

void test_spped_aes(){
  int i;
  uint64_t * k_sys;
  unsigned char key_raw_sys[16]  = "1234567891234567";
  uint8_t * key_raw = malloc(16);
  memcpy(key_raw, key_raw_sys, 16*sizeof(uint8_t));
  k_sys = offline_prg_keyschedule(key_raw);
  free(key_raw);
  ciphertext_1 = malloc(16);
  ciphertext_2 = malloc(16);
  ciphertext_3 = malloc(16);
  ciphertext_4 = malloc(16);

  uint8_t *plaintext_1 = malloc(16);
  uint8_t *plaintext_2 = malloc(16);
 uint8_t * plaintext_3 = malloc(16);
  uint8_t *plaintext_4 = malloc(16);
  struct timeval open_start;
  struct timeval open_end;
  unsigned long timer1;

__uint128_t *a = malloc(16);
__uint128_t *b = malloc(16);
__uint128_t *c = malloc(16);
__uint128_t *d = malloc(16);
printf("uint128 a and b:%d and %d\n",*a, *b);
printf("uint128 a and b:%d and %d\n",*a, *b);
memcpy(a,b,sizeof(__uint128_t));
printf("sizeof int128 %d\n", sizeof(__uint128_t) );
printf("sizeof int %d\n", sizeof(int) );
printf("uint128 a and b:%d and %d\n",*a, *b);
  gettimeofday(&open_start,NULL); //start timer here                      
 int j = 0;
  //#pragma omp parallel for num_threads(16)                              
  for(i =0; i<1024000;i++)
    {
//	switch(j)
//	{
//		case 0:
	if(j<0)
	{printf("aaa");
	}
	else if(j>0)
	{printf("bbb");}
	else if(j==0)
	{
	prg_aes_ni_quad(k_sys, a, b, c, d, plaintext_1, plaintext_2, plaintext_3, plaintext_4);
	//printf("ccc");
	}


    }

  gettimeofday(&open_end,NULL);//stop timer here                          

  timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
  printf("4aes and memcpy =%ld us\n",timer1);
printf("uint128 a and b:%d and %d\n",*a, *b);
  free(k_sys);
  free(a);
  free(b);
  free(c);
  free(d);
  free( ciphertext_1);
  free( ciphertext_2); 
  free( ciphertext_3);
  free( ciphertext_4);
  free( plaintext_1);
  free( plaintext_2);
  free( plaintext_3);
  free( plaintext_4);
}

void test_spped_aes_import(){
  int i;
  mpz_t tmp;
  mpz_init(tmp);
  uint64_t * k_sys;
  unsigned char key_raw_sys[16]  = "ijduybfhcidorufh";
  uint8_t * key_raw = malloc(16);
  memcpy(key_raw, key_raw_sys, 16*sizeof(uint8_t));
  k_sys = offline_prg_keyschedule(key_raw);
  free(key_raw);
  ciphertext_1 = malloc(16);
  ciphertext_2 = malloc(16);
  ciphertext_3 = malloc(16);
  ciphertext_4 = malloc(16);

  uint8_t *plaintext_1 = malloc(16);
  uint8_t *plaintext_2 = malloc(16);
 uint8_t * plaintext_3 = malloc(16);
  uint8_t *plaintext_4 = malloc(16);
  struct timeval open_start;
  struct timeval open_end;
  unsigned long timer1;
	mpz_t alpha_1, alpha_2, alpha_3,alpha_4;
	mpz_init(alpha_1);
	mpz_init(alpha_2);
	mpz_init(alpha_3);
	mpz_init(alpha_4);
  gettimeofday(&open_start,NULL); //start timer here                      
 int j = 0;
  //#pragma omp parallel for num_threads(16)                              
  for(i =0; i<1024000;i++)
    {
//	switch(j)
//	{
//		case 0:
	
	
	prg_aes_ni_quad_import_str(alpha_1, alpha_2, alpha_3,alpha_4, tmp, k_sys, plaintext_1, plaintext_2, plaintext_3, plaintext_4);
	//printf("ccc");
	
//	prg_aes_ni_quad(k_sys, plaintext_1, plaintext_2, plaintext_3, plaintext_4); //break;
//		case 1: printf("aaa"); break;
//		default:printf("bbb");
//	}

   }

  gettimeofday(&open_end,NULL);//stop timer here                          

  timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
  printf("4aes + str_conv =%ld us\n",timer1);

  free(k_sys);
  free( ciphertext_1);
  free( ciphertext_2); 
  free( ciphertext_3);
  free( ciphertext_4);
  free( plaintext_1);
  free( plaintext_2);
  free( plaintext_3);
  free( plaintext_4);	
	mpz_clear(alpha_1);
	mpz_clear(alpha_2);
	mpz_clear(alpha_3);
	mpz_clear(alpha_4);
  mpz_clear(tmp);
}

void test_spped_aes_export(){
  int i;
  mpz_t tmp;
  mpz_init(tmp);
  uint64_t * k_sys;
  unsigned char key_raw_sys[16]  = "ijduybfhcidorufh";
  uint8_t * key_raw = malloc(16);
  memcpy(key_raw, key_raw_sys, 16*sizeof(uint8_t));
  k_sys = offline_prg_keyschedule(key_raw);
  free(key_raw);
  ciphertext_1 = malloc(16);
  ciphertext_2 = malloc(16);
  ciphertext_3 = malloc(16);
  ciphertext_4 = malloc(16);

  uint8_t *plaintext_1 = malloc(16);
  uint8_t *plaintext_2 = malloc(16);
 uint8_t * plaintext_3 = malloc(16);
  uint8_t *plaintext_4 = malloc(16);
  struct timeval open_start;
  struct timeval open_end;
  unsigned long timer1;
	mpz_t alpha_1, alpha_2, alpha_3,alpha_4;
	mpz_init(alpha_1);
	mpz_init(alpha_2);
	mpz_init(alpha_3);
	mpz_init(alpha_4);
  gettimeofday(&open_start,NULL); //start timer here                      
 int j = 0;
  //#pragma omp parallel for num_threads(16)                              
  for(i =0; i<1024000;i++)
    {
//	switch(j)
//	{
//		case 0:
	
	
	prg_aes_ni_quad_export(alpha_1, alpha_2, alpha_3,alpha_4, tmp, k_sys, plaintext_1, plaintext_2, plaintext_3, plaintext_4);
	//printf("ccc");
	
//	prg_aes_ni_quad(k_sys, plaintext_1, plaintext_2, plaintext_3, plaintext_4); //break;
//		case 1: printf("aaa"); break;
//		default:printf("bbb");
//	}

   }

  gettimeofday(&open_end,NULL);//stop timer here                          

  timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
  printf("4aes + 4import + export=%ld us\n",timer1);

  free(k_sys);
  free( ciphertext_1);
  free( ciphertext_2); 
  free( ciphertext_3);
  free( ciphertext_4);
  free( plaintext_1);
  free( plaintext_2);
  free( plaintext_3);
  free( plaintext_4);	
	mpz_clear(alpha_1);
	mpz_clear(alpha_2);
	mpz_clear(alpha_3);
	mpz_clear(alpha_4);
  mpz_clear(tmp);
}

void test_spped_aes_4import(){
  int i;
  mpz_t tmp;
  mpz_init(tmp);
  uint64_t * k_sys;
  unsigned char key_raw_sys[16]  = "ijduybfhcidorufh";
  uint8_t * key_raw = malloc(16);
  memcpy(key_raw, key_raw_sys, 16*sizeof(uint8_t));
  k_sys = offline_prg_keyschedule(key_raw);
  free(key_raw);
  ciphertext_1 = malloc(16);
  ciphertext_2 = malloc(16);
  ciphertext_3 = malloc(16);
  ciphertext_4 = malloc(16);

  uint8_t *plaintext_1 = malloc(16);
  uint8_t *plaintext_2 = malloc(16);
 uint8_t * plaintext_3 = malloc(16);
  uint8_t *plaintext_4 = malloc(16);
  struct timeval open_start;
  struct timeval open_end;
  unsigned long timer1;
	mpz_t alpha_1, alpha_2, alpha_3,alpha_4;
	mpz_init(alpha_1);
	mpz_init(alpha_2);
	mpz_init(alpha_3);
	mpz_init(alpha_4);
  gettimeofday(&open_start,NULL); //start timer here                      
 int j = 0;
  //#pragma omp parallel for num_threads(16)                              
  for(i =0; i<1024000;i++)
    {
//	switch(j)
//	{
//		case 0:
	
	
	prg_aes_ni_quad_import(alpha_1, alpha_2, alpha_3,alpha_4, tmp, k_sys, plaintext_1, plaintext_2, plaintext_3, plaintext_4);
	//printf("ccc");
	
//	prg_aes_ni_quad(k_sys, plaintext_1, plaintext_2, plaintext_3, plaintext_4); //break;
//		case 1: printf("aaa"); break;
//		default:printf("bbb");
//	}


   }
printf("size of *cipher %d and %d \n",sizeof(*plaintext_1),sizeof(plaintext_1));
  gettimeofday(&open_end,NULL);//stop timer here                          

  timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
  printf("4aes + 4import =%ld us\n",timer1);

  free(k_sys);
  free( ciphertext_1);
  free( ciphertext_2); 
  free( ciphertext_3);
  free( ciphertext_4);
  free( plaintext_1);
  free( plaintext_2);
  free( plaintext_3);
  free( plaintext_4);	
	mpz_clear(alpha_1);
	mpz_clear(alpha_2);
	mpz_clear(alpha_3);
	mpz_clear(alpha_4);
  mpz_clear(tmp);
}

void test_spped_gnurand()
{
	int i;

	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	mpz_t d, d_base;
	mpz_init (d);
	mpz_init (d_base);
	mpz_ui_pow_ui (d_base, 2, 127);
	mpz_nextprime (d, d_base);


	unsigned long int seed = 2822;
	mpz_t seeds;
	mpz_init(seeds);
	mpz_set_d (seeds, seed);
 	gmp_randstate_t state;
	gmp_randinit_mt (state);
	gmp_randseed (state, seeds);
	mpz_t rnum;
	mpz_init(rnum);

	for(i =0; i<1024000;i++)
	{
		//mpz_urandomm (rnum, state, d);
		mpz_urandomb (rnum, state, 128);
	}

	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("1024000 times of mpz_random count %d = %ld us\n",i,timer1);
	

	mpz_clear(seeds);
	mpz_clear(d);
	mpz_clear(d_base);
	mpz_clear(rnum);
	gmp_randclear(state);
}

void convert_bit2(int index, int * binary, int ell)
{
	/*
	char bits[ell];
	int i;
	for(i = 0; i< ell; i++)
	{
		//strcpy(bits[i], 'a');
		bits[i] = 'a';
	}

	mpz_t storage;
	mpz_init (storage);
	mpz_set_ui(storage, index);
	mpz_get_str(bits, 2, storage);
	int tmp;
	for(i = ell - 1; i>=0; i--)
	{
		if(bits[i]=='a')
		{
			//strcpy(bits[i], '0');	
			bits[i] = '0';
		}
		else if((bits[i]!='1')&&(bits[i]!='0'))bits[i] = '0';
		
		tmp = bits[i] - '0';
		mpz_set_ui(mpz_array[ell-1-i], tmp);
		//printf("i[%d]:%d\n", i, tmp);

	}
	mpz_clear (storage);
*/
	int temp;
	//int binary[ell];
	int j;
	for(j=ell-1;j>=0;j--)
	{
		if(index == 0)
		{
			binary[j] = 0;		
		}
		else
		{
			binary[j] = index%2;
			index = index / 2;
		}
		//printf("%d", binary[j]);
	}
/*
	for(j=0;j<ell;j++)
	{
		printf("%d", binary[j]);
	}
	printf("\n");
*/
}

void test_spped_random(mpz_t d, gmp_randstate_t state)
{
	int i;
	mpz_t ran;
	mpz_init( ran);
	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here

	//#pragma omp parallel for num_threads(16) 
	for(i =0; i<1024000;i++)
	{
//mpz_urandomm (ran, state, d);
//mpz_urandomm (ran, state, d);
//mpz_urandomm (ran, state, d);
//mpz_urandomm (ran, state, d);

 mpz_urandomb (ran, state, 128);
 //mpz_urandomb (ran, state, 128);
 //mpz_urandomb (ran, state, 128);
 //mpz_urandomb (ran, state, 128);
	}

	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("random  =%ld us\n",timer1);
	mpz_clear( ran);
}

void test_spped_count()
{
	int i;

	struct timeval open_start;
	struct timeval open_end;
	unsigned long timer1;

	gettimeofday(&open_start,NULL); //start timer here



	for(i =0; i<1024000;i++)
	{

	}

	gettimeofday(&open_end,NULL);//stop timer here

	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
	printf("1024000 of do nothing count %d = %ld us\n",i,timer1);

}



int main()
{
	
	gmp_randstate_t state;
	gmp_randinit_mt (state);

	uint8_t plain[]      = {0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34};
	mpz_t a, d, d_base;
	mpz_init(a);
	mpz_init(d);
	mpz_init(d_base);
	mpz_ui_pow_ui (d_base, 2, 127);
	mpz_nextprime(d, d_base);	



	mpz_import(a, 16, 1, sizeof(uint8_t), 0, 0, plain);
	gmp_randseed (state, a);
	int j;
//	int binary[20];
//	mpz_t * array = Init_one (20);

//	for(j=0;j<1000000;j++)
//	{
//		convert_bit2(1, binary,  20);
//	}

test_spped_basic();
test_spped_mul();
test_spped_add_mul();
test_spped_add();
test_spped_mod();
test_spped_set();
test_spped_addmul();
test_spped_init_clear();
test_spped_malloc_free();
 test_spped_aes();
test_spped_aes_import();
test_spped_random(d, state);
test_spped_aes_4import();
test_spped_aes_export();
 test_spped_count();
test_spped_gnurand();
/*
	for(j=0;j<20;j++)
	{
		mpz_clear (array[j]);
	}
*/

//	for(j=0;j<20;j++)
//	{
//		printf("%d", binary[j]);
//	}
mpz_clear(a);
mpz_clear(d);
mpz_clear(d_base);
gmp_randclear (state);
	printf("\n");
	return 0;
}
