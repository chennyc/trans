#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <wmmintrin.h>
#include <tmmintrin.h>
#include <gmp.h> 
#include <omp.h>
#include <gcrypt.h>
#include "Network.h"
#include "Rotation.h"

void mpzout(mpz_t * op, int num)
{

	int i;
	for(i = 0; i < num; i++)
      	gmp_printf("%Zd, ",op[i]);

	printf("\n");
}

void clear_one (int num, mpz_t * op){

	int i;
	for(i = 0; i < num; i++)
      	mpz_clear(op[i]);
	//return op;
	free(op);
}

void rotation(mpz_t * op, mpz_t * op2, int num, int offset)
{
	memcpy(op2[0], op[offset], sizeof(mpz_t)*(num - offset));
	memcpy(op2[num - offset], op[0], sizeof(mpz_t)*offset);
	memcpy(op[0], op2[0], sizeof(mpz_t)*num);

}

void conver_MtoB(mpz_t * op,int num, uint8_t * buffer, int offset)
{
// 	struct timeval send_start;
//  	struct timeval send_end;
//	unsigned long timer_send;

//	gettimeofday(&send_start,NULL); //start timer here 

	int i;
	int offrest=num-offset;
	for(i = 0; i < offset; i++)
      	{
		mpz_export(buffer + 16*(i+offrest), NULL, 1, 16, 0, 0, op[i]);
	}
	for(i = 0; i < offrest; i++)
      	{
		mpz_export(buffer + 16*i, NULL, 1, 16, 0, 0, op[i+offset]);
	}

// 	gettimeofday(&send_end,NULL);//stop timer here                          

//  	timer_send = 1000000 * (send_end.tv_sec-send_start.tv_sec)+ send_end.tv_usec-send_start.tv_usec;
//  	printf("--------------time cost in convermb =%ld us\n", timer_send);

}

void conver_BtoM(mpz_t * op,int num, uint8_t * buffer)
{
// 	struct timeval send_start;
//  	struct timeval send_end;
//	unsigned long timer_send;

//	gettimeofday(&send_start,NULL); //start timer here 

	int i;
	for(i = 0; i < num; i++)
      	{
		mpz_import(op[i], 1, 1, 16, 0, 0, buffer + 16*i);
	}
// 	gettimeofday(&send_end,NULL);//stop timer here                          

// 	timer_send = 1000000 * (send_end.tv_sec-send_start.tv_sec)+ send_end.tv_usec-send_start.tv_usec;
// 	printf("--------------time cost in converbm =%ld us\n", timer_send);
}

void SplitArray(mpz_t * op, mpz_t * op2, int num, gmp_randstate_t state, mpz_t d)
{
//	struct timeval send_start;
//  	struct timeval send_end;
//	unsigned long timer_send;

//	gettimeofday(&send_start,NULL); //start timer here  

	int i;




	for(i =0; i<num;i++)
	{	
//		if(i==0)
//		printf("In the split now\n");
		mpz_urandomb (op2[i], state, BitBase);
//		gmp_printf("The %d-th rnum is: %Zd \n",i,op2[i]);
//removmod		mpz_mod(buf,op2[i],d);
//removmod		mpz_set(op2[i],buf);

//		gmp_printf("The %d-th buf after mod is: %Zd \n",i,buf);
//		gmp_printf("The %d-th rnum after mod is: %Zd \n",i,op2[i]);
//		gmp_printf("The %d-th paras before sub is: %Zd and %Zd\n",i,op[i],op2[i]);
		mpz_sub(op[i],op[i],op2[i]);
//		gmp_printf("The %d-th buf after sub is: %Zd \n",i,buf);
//		gmp_printf("The %d-th share is: %Zd \n",i,op[i]);
		mpz_mod(op[i],op[i],d);
//		gmp_printf("The %d-th share after mode is: %Zd \n\n\n",i,op[i]);
	}

//  	gettimeofday(&send_end,NULL);//stop timer here                          
//  	timer_send = 1000000 * (send_end.tv_sec-send_start.tv_sec)+ send_end.tv_usec-send_start.tv_usec;
//  	printf("--------------time cost in split =%ld us\n", timer_send);

}

void CombineArray(mpz_t * op, mpz_t * op2, mpz_t * op3, int num, int offset, mpz_t d) //op is one's unrotatetd share, op3 is other's rotated share, op2 is the conbined
{
// 	struct timeval send_start;
//  	struct timeval send_end;
//	unsigned long timer_send;

//	gettimeofday(&send_start,NULL); //start timer here  

	int i;
	int offrest = num-offset;
	for(i =0; i<offrest;i++)
	{
		mpz_add(op2[i],op[offset+i],op3[i]);
		mpz_mod(op2[i],op2[i],d);
	}
	for(i =0; i<offset;i++)
	{
		mpz_add(op2[i+offrest],op[i],op3[i+offrest]);
		mpz_mod(op2[i+offrest],op2[i+offrest],d);
	}
// 	gettimeofday(&send_end,NULL);//stop timer here                          

// 	timer_send = 1000000 * (send_end.tv_sec-send_start.tv_sec)+ send_end.tv_usec-send_start.tv_usec;
// 	printf("--------------time cost in combine =%ld us\n", timer_send);

}

