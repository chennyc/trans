#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <wmmintrin.h>
#include <tmmintrin.h>
#include <gmp.h> 
#include <omp.h>
#include <gcrypt.h>
#include "Network.h"
#include "Rotation.h"


mpz_t d, d_base;
/*
mpz_t* Init_one (int num){

	int i;
	mpz_t * op=malloc(sizeof(mpz_t) * num);
	for(i = 0; i < num; i++)
      	mpz_init(op[i]);
	mpz_set_ui(op[i]);
	return op;
}
*/



int main(int argc, char *argv[])
{
	int detail;
	detail=1;
	int i;
	int num;
	int offset=5;
	int r1=1;
	int r2=2;
	int index=3;
	int iteration,times;

	mpz_init (d);
	mpz_init (d_base);
	mpz_ui_pow_ui (d_base, 2, BitBase);
	mpz_nextprime (d, d_base);
	num=atol(argv[4]);
	iteration=atol(argv[5]);
	times=atol(argv[6]);
	detail=atol(argv[7]);

	gmp_printf("The d and d_base item is: %Zd and %Zd \n",d,d_base);


	uint8_t * buffer = (uint8_t *)malloc(16*num);

//printf("Ttttttt\n");
/*######################################Network setup start######################################*/


	char msgbuffer1[64*sizeof(uint8_t)];
	char msgbuffer2[16*sizeof(uint8_t)];
	uint8_t * tmp_buf = malloc(16);
	int neighfd[3]={-1,-1,-1};
struct memberlist memberp[4]={
	    {4,"abc.a.ad",-1},
	    {4,"abc.a.ad",-1},
	    {4,"abc.a.ad",-1},
	    {4,"abc.a.ad",-1}};
	struct memberlist *mp=memberp;
	struct message storemsg={0,"0123456789012345"};
	struct message *msgp=&storemsg;

	struct memberlist *p;
	p=mp;

	char c = getopt(argc, argv, "a:b:c:");
	//char opt_num[10];
	printf("input:%c\n", c);
	switch(c)
	{
		case 'a': //a means party 1 ,L=2, R=3
		{
		//seeds=1024;
		//init_mem(Mem_L, seeds);
		//seeds=1025;
		//init_mem(Mem_R, seeds);
		p->party_no=1;
		p++;
		p->party_no=2;
		strcpy(p->memberadd, optarg);
		p++;
		p->party_no=3;
		strcpy(p->memberadd, argv[optind]);

		};break;

		case 'b': //b party 2, ,L=1, R=3
		{
		//seeds=1024;
		//init_mem( Mem_L, seeds);
		//seeds=1025;
		//init_mem(Mem_R, seeds);


		p->party_no=2;
		p++;
		p->party_no=3;
		strcpy(p->memberadd, optarg);
		p++;
		p->party_no=1;
		strcpy(p->memberadd, argv[optind]);
      		};break;

    		case 'c': //c party 3, L=1, R=2
      		{


		p->party_no=3;
		p++;
		p->party_no=1;
		strcpy(p->memberadd, optarg);
		p++;
		p->party_no=2;
		strcpy(p->memberadd, argv[optind]);
      		};break;
    	}
  printf("This is num %d and iter %d  \n", num,iteration);
  p=mp;
  printf("This is P%d \n", p->party_no);
  p++;
  printf("This is P %d' IP addres:%s\n", p->party_no, p->memberadd);
  p++;
  printf("this is P %d' IP addres:%s\n", p->party_no, p->memberadd);

  p=mp;
   printf("my name is %d \n", p->party_no);


	//gmp_randstate_t prg_state;
	switch(p->party_no) //connect to each other
	{
		case 1:	setconnect_a(mp,msgp,neighfd);
		break;
		case 2:	setconnect_b(mp,msgp,neighfd);
		break;
		case 3:	printf("my name is %d \n", p->party_no);
			setconnect_c(mp,msgp,neighfd);
		break;
	}



	memset(buffer,0,16*num);
	
	switch(p->party_no)
	{
		case 1:	
			send(neighfd[1],buffer,16*num,0);
			send(neighfd[3],buffer,16*num,0);
			memset(buffer,0,sizeof(int));
			recv(neighfd[4],buffer,16*num,MSG_WAITALL);	//recv from 2
			recv(neighfd[2],buffer,16*num,MSG_WAITALL);	//recv from 3
		break;
		case 2:	
			recv(neighfd[2],buffer,16*num,MSG_WAITALL);
			send(neighfd[1],buffer,16*num,0);
			send(neighfd[3],buffer,16*num,0);
		break;
		case 3:				
			recv(neighfd[2],buffer,16*num,MSG_WAITALL);
			recv(neighfd[4],buffer,16*num,MSG_WAITALL);
			send(neighfd[1],buffer,16*num,0);
		break;
	}


	int sys;
	switch(p->party_no) //connect to each other
	{
		case 1:	
			sys=100;
			memset(buffer,0,sizeof(int));
			memcpy(buffer,&sys,sizeof(int));
			send(neighfd[1],buffer,sizeof(int),0);
			memcpy(&sys,buffer,sizeof(int));
			printf("send %d\n",sys);
			memset(buffer,0,sizeof(int));
			recv(neighfd[2],buffer,sizeof(int),MSG_WAITALL);	//recv from 3
			memcpy(&sys,buffer,sizeof(int));
			printf("recved %d\n",sys);			
		break;
		case 2:	
			memset(buffer,0,sizeof(int));
			recv(neighfd[2],buffer,sizeof(int),MSG_WAITALL);
			memcpy(&sys,buffer,sizeof(int));
			printf("recved %d\n",sys);
			memset(buffer,0,sizeof(int));
			memcpy(buffer,&sys,sizeof(int));
			send(neighfd[1],buffer,sizeof(int),0);
			memcpy(&sys,buffer,sizeof(int));
			printf("send %d\n",sys);
		break;
		case 3:				
			memset(buffer,0,sizeof(int));
			recv(neighfd[2],buffer,sizeof(int),MSG_WAITALL);
			memcpy(&sys,buffer,sizeof(int));
			printf("recved %d\n",sys);
			memset(buffer,0,sizeof(int));
			memcpy(buffer,&sys,sizeof(int));
			send(neighfd[1],buffer,sizeof(int),0);
			memcpy(&sys,buffer,sizeof(int));
			printf("send %d\n",sys);
		break;
	}

/*######################################Network setuo end######################################*/


/*####################Computation start from here##############*/
	int syn;
 	struct timeval open_start;
  	struct timeval open_end;
	unsigned long timer1;

 	struct timeval start2;
  	struct timeval end2;
	unsigned long timer2;

	struct timeval start3;
 	struct timeval end3;
	unsigned long timer3;

 	struct timeval start4;
 	struct timeval end4;
	unsigned long timer4;

	mpz_t * op=malloc(sizeof(mpz_t) * num);
	mpz_t * op2=malloc(sizeof(mpz_t) * num);
	mpz_t * op3=malloc(sizeof(mpz_t) * num);
	for(i = 0; i < num; i++) 
      	{
		mpz_init(op[i]);
		mpz_init(op2[i]);
		mpz_init(op3[i]);
	}


	int HiddenIndex=(index-r1-r2) % num;
	printf("hiddenindex is %d\n",HiddenIndex);


	unsigned long int seed1=1000;
	unsigned long int seed2=2000;

	mpz_t seeds1, seeds2;
	mpz_init(seeds1);
	mpz_init(seeds2);

	mpz_set_d (seeds1, seed1);
	mpz_set_d (seeds2, seed2);
 	gmp_randstate_t state1;
	gmp_randinit_mt (state1);
 	gmp_randstate_t state2;
	gmp_randinit_mt (state2);

	gmp_randseed (state1, seeds1);
	gmp_randseed (state2, seeds2);




	mpz_t alpha, beta;
	mpz_init(alpha);
	mpz_init(beta);
	int j,k;	
	long int best_result = 999999999;
	long int best_trans = 999999999;

	switch(p->party_no) //
	{
		case 1:	
			for(i = 0; i < num; i++) 		//assume the share of P1 is 1,2,3,4,... ,n+1 too
      			{
				mpz_set_ui(op[i],i+1);
			}
		break;
		case 2:	
			for(i = 0; i < num; i++)		//assume the share of P1 is 1,2,3,4,...,n+1 too
      			{
				mpz_set_ui(op[i],i+1);
			}
		break;
		case 3:	
		break;
	}
for(k=0;k<times;k++)
{
	gettimeofday(&open_start,NULL); //start timer here   
	for(j=0;j<iteration;j++)
	{
		index++;
		HiddenIndex=(index-r1-r2) % num;	
	switch(p->party_no) //
	{
		case 1:	
			if(detail==1)
			{			
				mpzout(op,num);				
				mpzout(op2,num);
			}
			
			offset=r1 % num;
			//rotation(op, op2, num, offset);		//rotate the share of P1 with offest of r1 mod num
			if(detail==1)
			{
				printf("After rotation:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op2: ");				
				mpzout(op2,num);
			}
			SplitArray(op, op3, num, state1, d);	//split the share of P1 into two parts;
			if(detail==1)
			{
				printf("After split:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op3: ");				
				mpzout(op3,num);
			}

	gettimeofday(&start2,NULL); //start timer here

			memset(buffer,0,16*num);
			conver_MtoB(op, num, buffer, offset);
			send(neighfd[1],buffer,16*num,0);	//send one part to P2
			memset(buffer,0,16*num);
			conver_MtoB(op3, num, buffer, offset);
			send(neighfd[3],buffer,16*num,0);	//send one part to P3

  	gettimeofday(&end2,NULL);//stop timer here    
  	timer2 = 1000000 * (end2.tv_sec-start2.tv_sec)+ end2.tv_usec-start2.tv_usec;
//  	printf("--------------time cost in two send =%ld us\n", timer2);


	gettimeofday(&start3,NULL); //start timer here

			memset(buffer,0,16*num);
			recv(neighfd[4],buffer,16*num,MSG_WAITALL);	//recv from 2
			conver_BtoM(op, num, buffer);
 	gettimeofday(&end3,NULL);//stop timer here    
  	timer3 = 1000000 * (end3.tv_sec-start3.tv_sec)+ end3.tv_usec-start3.tv_usec;
// 	printf("--------------time cost in wait and recv from2 =%ld us\n", timer3);



			if(detail==1)
			{
				printf("After recv from 2:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op2: ");				
				mpzout(op2,num);
			}

	gettimeofday(&start4,NULL); //start timer here
			mpz_set(alpha, op[HiddenIndex]);

			memset(buffer,0,16*num);
			recv(neighfd[2],buffer,16,MSG_WAITALL);		//recv the requested share from 3

  	gettimeofday(&end4,NULL);//stop timer here    
  	timer4 = 1000000 * (end4.tv_sec-end3.tv_sec)+ end4.tv_usec-end3.tv_usec;
// 	printf("--------------time cost in wait and recv from3 =%ld us\n", timer4);

			mpz_import(beta, 1, 1, 16, 0, 0, buffer);

			if(detail==1)
			{
				printf("After recved from 3:\n");
				printf("This is hiden ");				
     			 	gmp_printf("%Zd \n",op2[HiddenIndex]);
				printf("This is alpha ");				
     			 	gmp_printf("%Zd \n",alpha);
				printf("This is beta ");				
     			 	gmp_printf("%Zd \n",beta);
			}

			mpz_add(alpha, alpha, beta);
			mpz_mod(alpha,alpha,d);
			if(detail<=2)
			{
			gmp_printf("The %d-th requested item is: %Zd \n",j,alpha);
			printf("I am 1 and I'm done now \n");
			}
				
/*			syn=j;
			memcpy(buffer,&syn,sizeof(int));
			send(neighfd[1],buffer,sizeof(int),0);
			recv(neighfd[2],buffer,sizeof(int),0);	//recv from 3.
			memcpy(&syn,buffer,sizeof(int));
			printf("recved %d \n", syn);
			if(syn==j+2)
			{
				printf("syn between parties fine \n");
			}
*/
		break;
		case 2:	
			if(detail==1)
			{
				printf("After setup:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op2: ");				
				mpzout(op2,num);
			}
			offset=r1 % num;
			//rotation(op, op2, num, offset);		//rotate the share of P2 with offest of r1 mod num
			if(detail==1)
			{
				printf("After rotation:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op2: ");				
				mpzout(op2,num);
			}
			memset(buffer,0,16*num);
			recv(neighfd[2],buffer,16*num,MSG_WAITALL);	//recv from 1
			conver_BtoM(op3, num, buffer);
//	gettimeofday(&start2,NULL); //start timer here


			if(detail==1)
			{
				printf("After recv from 1:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op3: ");				
				mpzout(op3,num);
			}
			CombineArray(op, op2, op3, num, offset,d);		//the combined share is in op now:op is 2's unrotatetd share, op3 is 1's rotated share, op2 is the conbined
			if(detail==1)
			{
				printf("After combined:\n");
				printf("This is op2: ");				
				mpzout(op2,num);
				printf("This is op3: ");				
				mpzout(op3,num);
			}
			offset=r2 % num;
			//rotation(op, op2, num, offset);		//rotate the share of P2 with offest of r2 mod num
			if(detail==1)
			{
				printf("After rotation:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op3: ");				
				mpzout(op3,num);
			}
			SplitArray(op2, op3, num, state2, d);	//split the share of P2 into two parts;
			if(detail==1)
			{
				printf("After split:\n");
				printf("This is op2: ");				
				mpzout(op2,num);
				printf("This is op3: ");				
				mpzout(op3,num);
			}

//  	gettimeofday(&end2,NULL);//stop timer here    
//  	timer2 = 1000000 * (end2.tv_sec-start2.tv_sec)+ end2.tv_usec-start2.tv_usec;
//  	printf("--------------time cost in combine and split =%ld us\n", timer2);

//	gettimeofday(&start3,NULL); //start timer here


			memset(buffer,0,16*num);
			conver_MtoB(op2, num, buffer, offset);
			send(neighfd[3],buffer,16*num,0);	//send one part to P1
			memset(buffer,0,16*num);
			conver_MtoB(op3, num, buffer, offset);
			send(neighfd[1],buffer,16*num,0);	//send one part to P3

//  	gettimeofday(&end3,NULL);//stop timer here    
//  	timer3 = 1000000 * (end3.tv_sec-start3.tv_sec)+ end3.tv_usec-start3.tv_usec;
//  	printf("--------------time cost in two send =%ld us\n", timer3);
			if(detail<=2)
			{			
			printf("I am 2 and I'm done now \n");
			}
/*			
			memset(buffer,0,16*num);
			recv(neighfd[2],buffer,sizeof(int),0);	//recv from 1
			memcpy(&syn,buffer,sizeof(int));
			printf("recved %d \n", syn);
			if(syn==j)
			{
				syn++;
				memcpy(buffer,&syn,sizeof(int));
				send(neighfd[1],buffer,sizeof(int),0);			
			}
			else
			{
				printf("syn break;");
				break;
			}
*/
		break;
		case 3:	
			if(detail==1)
			{
				printf("After setup:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op2: ");				
				mpzout(op2,num);
			}
			memset(buffer,0,16*num);
			recv(neighfd[4],buffer,16*num,MSG_WAITALL);	//recv from 1
			conver_BtoM(op, num, buffer);
			if(detail==1)
			{
				printf("After recv from 1:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op2: ");				
				mpzout(op2,num);
			}
			offset=r2 % num;
			//rotation(op, op2, num, offset);		//rotate the share of P3 with offest of r2 mod num
			if(detail==1)
			{
				printf("After rotation:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op2: ");				
				mpzout(op2,num);
			}
			memset(buffer,0,16*num);
			recv(neighfd[2],buffer,16*num,MSG_WAITALL);	//recv from 2
			conver_BtoM(op3, num, buffer);

//	gettimeofday(&start2,NULL); //start timer here


			if(detail==1)
			{
				printf("After recv from 2:\n");
				printf("This is op: ");				
				mpzout(op,num);
				printf("This is op3: ");				
				mpzout(op3,num);
			}
			CombineArray(op, op2, op3, num, offset, d);		//the combined share is in op now
			if(detail==1)
			{
				printf("After combined:\n");
				printf("This is op2: ");				
				mpzout(op2,num);
				printf("This is op3: ");				
				mpzout(op3,num);
			}
			memset(buffer,0,16*num);
			mpz_export(buffer, NULL, 1, 16, 0, 0, op2[HiddenIndex]);
			send(neighfd[1],buffer,16,0);	//send one part to P1

//  	gettimeofday(&end2,NULL);//stop timer here    
//  	timer2 = 1000000 * (end2.tv_sec-start2.tv_sec)+ end2.tv_usec-start2.tv_usec;
//  	printf("--------------time cost in combiune and send =%ld us\n", timer2);
			if(detail==1)
			{
				printf("After send to 1\n");
				printf("This is gamma ");				
     			 	gmp_printf("%Zd \n",op[HiddenIndex]);
			}
			if(detail<=2)
			{
			printf("I am 3 and I'm done now \n");
			}
/*
			memset(buffer,0,16*num);
			recv(neighfd[2],buffer,sizeof(int),0);	//recv from 1
			memcpy(&syn,buffer,sizeof(int));
			printf("recved %d \n", syn);
			if(syn==j+1)
			{
				syn++;
				memcpy(buffer,&syn,sizeof(int));
				send(neighfd[1],buffer,sizeof(int),0);	
			}
			else
			{
				printf("syn break;");
				break;
			}
*/
		break;
	}

	}

  	gettimeofday(&open_end,NULL);//stop timer here                          

  	timer1 = 1000000 * (open_end.tv_sec-open_start.tv_sec)+ open_end.tv_usec-open_start.tv_usec;
  	printf("%d times table (size=%d) lookup =%ld us\n",iteration, num, timer1);
	if(p->party_no==1&&best_result>timer1)
	{
		best_result=timer1;
		best_trans=timer2+timer3+timer4;
	}
}
  	printf("The best result during the %d times of %d-iteration of table (size=%d) lookup =%ld us\n",times, iteration, num, best_result);
  	printf("The best_trans of best result =%ld us\n",best_trans);
	mpz_clear(alpha);
	mpz_clear(beta);
	printf("Lookup finished\n");
/*####################Computation end from here##############*/
/*####################Clerance##############*/
	printf("Clerance\n");
	mpz_clear(seeds1);
	gmp_randclear(state1);
	mpz_clear(seeds2);
	gmp_randclear(state2);
	mpz_clear(d);
	mpz_clear(d_base);
	clear_one (num, op3);
	clear_one (num, op);
	clear_one (num, op2);
	close(neighfd[1]);

	close(neighfd[3]);

	free(buffer);
	free(tmp_buf);
	printf("Clerance finished\n");
	return 0;
}
