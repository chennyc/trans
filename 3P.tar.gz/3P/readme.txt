############
Test_Convert.c (this needs libaes.a)

This file is used to measure the performances of some basic computation.

gcc -o test_con Test_Convert.c -fopenmp -L. libaes.a libgmp.a 


############
Compile Lookup: make
Run lookup:$./Lookup -p ip1 ip2 table_size iteration times detail

	-p means which patry (a/b/c) to be.

	ip1 and ip2 represent the ip addresses of the other two parties. For a, ip1=b's ip, ip2=c'ip; For b, ip1=c's ip, ip2=a'ip; 			For c, ip1=a's ip, ip2=b'ip.

	table_size: Just the table size, any integer works (16/64/256... used in previous experiments).

	iteration: How many table lookup will be done in a row, any integer works(1/10/100/1000 used in previous experiments).
	
	times: How many iteration will be run in this execution, any integer works but 100 would be good enough. 

	detail: How much intermediate results would be print out. 
		1: Almost everything, including the random values, all shares after rotation, combine, and split
		2: Only output the final reconstructed requested item
		3: Nothing but the best result

	Example:
		At Party 1 with ip address of $r1ip:$./Lookup -a $r2ip $r3ip 65536 10 100 3
		At Party 3 with ip address of $r3ip:$./Lookup -a $r1ip $r2ip 65536 10 100 3
		At Party 2 with ip address of $r2ip:$./Lookup -a $r3ip $r1ip 65536 10 100 3
		(Must run P1, P3, P2 in order)

		This will setup an database with 65536 items. There will be 100 times of iteration be executed and 10 table lookup 			in each interation. After all operations, the smallest time for 10 table lookup operation will be printed out.
		
