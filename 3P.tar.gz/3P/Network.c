#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include "Network.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h> 


void setconnect_a(struct memberlist *mp, struct message *msgp, int *neighfd)
{
struct memberlist *p;

  int connfd, lisfd,connfd2, lisfd2, sock_fd, sock_fd2;
  p=mp;
  p++;
  char msgbuf[sizeof(struct message)];


  struct sockaddr_in server_addr;

  if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("listen error");
  }
int enable = 1;
if (setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");//////


  bzero(&server_addr, sizeof(struct sockaddr_in));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr.sin_port = htons(LIS_PORT);

  if (bind(sock_fd, (struct sockaddr *)(&server_addr), sizeof(struct sockaddr)) == -1) {
    perror("bind111 error");
  }
//printf("this is after bind \n");
  //int listen_flag = 0;

  if(listen(sock_fd, 2) == -1) {
    perror("listen error");
    exit(1);
  }

//printf("this is after listen \n");//waitting for 3

lisfd = accept(sock_fd, (struct sockaddr *)NULL, NULL);
  if ( lisfd == -1) {
    perror("accpet error");
    exit(1);
  }

//printf("this is after accept \n");//accept 3's request

  p=mp+2;
  char * servInetAddr2 = p->memberadd;
 // printf("this is servInetAddr2 of 3: %s \n", servInetAddr2);
  int servPort = LIS_PORT2;
  socklen_t socklen = sizeof(struct sockaddr_in);
  //int connfd;
  struct sockaddr_in servaddr2, claddr2;
  connfd2 = socket(AF_INET, SOCK_STREAM, 0);
  // FD_ZERO(rset);
  p->keepfd=connfd2;
  bzero(&claddr2, sizeof(claddr2));
  claddr2.sin_family = AF_INET;
  claddr2.sin_addr.s_addr = htonl(INADDR_ANY);
  claddr2.sin_port = htons(LOC_PORT2);
if (setsockopt(connfd2, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");
  bind(connfd2, (struct sockaddr*)&claddr2, socklen);
  bzero(&servaddr2, sizeof(servaddr2));
  servaddr2.sin_family = AF_INET;
  servaddr2.sin_port = htons(servPort);
  inet_pton(AF_INET, servInetAddr2, &servaddr2.sin_addr);
  if (connect(connfd2, (struct sockaddr *) &servaddr2, sizeof(servaddr2)) < 0) {
    perror("connect error");
  }
//  printf("this is after connection with 3\n");//connected with 3

  int flags  = fcntl(lisfd,F_GETFL,0);       
  fcntl(lisfd,F_SETFL,flags&~O_NONBLOCK);    

  memset(msgbuf,0,sizeof(msgbuf));
  recv(lisfd,msgbuf,sizeof(*msgp),0 );
  memset(msgp,0,sizeof(*msgp));
  memcpy(msgp,msgbuf,sizeof(*msgp));

  if (msgp->stats != 10)  //10 means party-2 is online now.
    {
      perror("recv error");
      exit(1);
    }


//  printf("this is after rev\n");

  p=mp+1;
  char * servInetAddr = p->memberadd;
//  printf("this is servInetAddr: %s \n", servInetAddr);
  servPort = LIS_PORT;
  //socklen_t socklen = sizeof(struct sockaddr_in);
  //int connfd;
  struct sockaddr_in servaddr, claddr;
  connfd = socket(AF_INET, SOCK_STREAM, 0);
  // FD_ZERO(rset);
  p->keepfd=connfd;
  bzero(&claddr, sizeof(claddr));
  claddr.sin_family = AF_INET;
  claddr.sin_addr.s_addr = htonl(INADDR_ANY);
  claddr.sin_port = htons(LOC_PORT);
if (setsockopt(connfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");
  bind(connfd, (struct sockaddr*)&claddr, socklen);
  bzero(&servaddr, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_port = htons(servPort);
  inet_pton(AF_INET, servInetAddr, &servaddr.sin_addr);
  if (connect(connfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
    perror("connect error");
  }
//  printf("this is after connection with 2\n");


  struct sockaddr_in server_addr2;

  if ((sock_fd2 = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("listen error");
  }



  bzero(&server_addr2, sizeof(struct sockaddr_in));
  server_addr2.sin_family = AF_INET;
  server_addr2.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr2.sin_port = htons(LIS_PORT2);

if (setsockopt(sock_fd2, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");//////
  if (bind(sock_fd2, (struct sockaddr *)(&server_addr2), sizeof(struct sockaddr)) == -1) {
    perror("bind error");
  }
//printf("this is after bind \n");
  //int listen_flag = 0;

  if(listen(sock_fd2, 2) == -1) {
    perror("listen error");
    exit(1);
  }

//printf("this is after listen \n");//waitting for 2

lisfd2 = accept(sock_fd2, (struct sockaddr *)NULL, NULL);
  if ( lisfd == -1) {
    perror("accpet error");
    exit(1);
  }

//printf("this is after accept \n");//accept 3's request
/*
  msgp->stats=mp->party_no;    
  memset(msgbuf,0,sizeof(msgbuf));
  memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(connfd,msgbuf,sizeof(*msgp),0);
  p->keepfd=connfd;
*/

/*
p=mp+1;
if(close(p->keepfd)<0)
{
    perror("close1 error");
    exit(1);
}
p++;
if(close(p->keepfd)<0)
{
    perror("close2 error");
    exit(1);
}
*/
  neighfd[1]= connfd; // 1->2
  neighfd[2]= lisfd;  // 1<-3
  neighfd[3]= connfd2;//1->3
  neighfd[4]= lisfd2;//1<-2

  memset(msgp,0,sizeof(*msgp));
  msgp->stats=12;    
  memset(msgbuf,0,sizeof(msgbuf));
  memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[1],msgbuf,sizeof(*msgp),0);

  memset(msgp,0,sizeof(*msgp));
  msgp->stats=13;    
  memset(msgbuf,0,sizeof(msgbuf));
  memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[3],msgbuf,sizeof(*msgp),0);

  memset(msgbuf,0,sizeof(msgbuf));
  recv(neighfd[2],msgbuf,sizeof(*msgp),0 );
  memset(msgp,0,sizeof(*msgp));
  memcpy(msgp,msgbuf,sizeof(*msgp));
  printf("1.received(3):%d\n",msgp->stats);

  memset(msgbuf,0,sizeof(msgbuf));
  recv(neighfd[4],msgbuf,sizeof(*msgp),0 );
  memset(msgp,0,sizeof(*msgp));
  memcpy(msgp,msgbuf,sizeof(*msgp));
  printf("2.received(2):%d\n",msgp->stats);
  //if (msgp->stats != 2)  //2 means the accepted party is 2.
  //{
  //perror("recv error");
  //exit(1);
  //}

}



void setconnect_b(struct memberlist *mp, struct message *msgp, int *neighfd)
{
  struct memberlist *p;

  int connfd, lisfd, sock_fd, connfd2, lisfd2, sock_fd2;
  p=mp;
  p++;
  char msgbuf[sizeof(struct message)];


  // the party 2 will try to connect party 3 at first.
  char * servInetAddr = p->memberadd;
  //printf("this is servInetAddr: %s \n", servInetAddr);
  int servPort = LIS_PORT;
  socklen_t socklen = sizeof(struct sockaddr_in);
  //int connfd;
  struct sockaddr_in servaddr, claddr;
  connfd = socket(AF_INET, SOCK_STREAM, 0);
  // FD_ZERO(rset);

  bzero(&claddr, sizeof(claddr));
  claddr.sin_family = AF_INET;
  claddr.sin_addr.s_addr = htonl(INADDR_ANY);
  claddr.sin_port = htons(LOC_PORT);
int enable = 1;
if (setsockopt(connfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");
  bind(connfd, (struct sockaddr*)&claddr, socklen);
  bzero(&servaddr, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_port = htons(servPort);
  inet_pton(AF_INET, servInetAddr, &servaddr.sin_addr);
  if (connect(connfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
    perror("connect error");
  }

  p->keepfd=connfd;

//printf("this is after connect with 3\n");

  //then party 2 wait for the party 3
  struct sockaddr_in server_addr2;

  if ((sock_fd2 = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("listen error");
  }


if (setsockopt(sock_fd2, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");//////

  bzero(&server_addr2, sizeof(struct sockaddr_in));
  server_addr2.sin_family = AF_INET;
  server_addr2.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr2.sin_port = htons(LIS_PORT2);

  if (bind(sock_fd2, (struct sockaddr *)(&server_addr2), sizeof(struct sockaddr)) == -1) {
    perror("bind error");
  }

  //int listen_flag = 0;

  if(listen(sock_fd2, 2) == -1) {
    perror("listen error");
    exit(1);
  }

//printf("this is after listen and before accept with 3\n");



lisfd2 = accept(sock_fd2, (struct sockaddr *)NULL, NULL);

  if (lisfd2 == -1) {
    perror("accpet error");
    exit(1);
  }
//printf("this is after accepted 3\n");


  //then party 2 wait for the party 1
  struct sockaddr_in server_addr;

  if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("listen error");
  }



  bzero(&server_addr, sizeof(struct sockaddr_in));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr.sin_port = htons(LIS_PORT);
if (setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");//////
  if (bind(sock_fd, (struct sockaddr *)(&server_addr), sizeof(struct sockaddr)) == -1) {
    perror("bind error");
  }

  //int listen_flag = 0;

  if(listen(sock_fd, 2) == -1) {
    perror("listen error");
    exit(1);
  }



msgp->stats=2;
memset(msgbuf,0,sizeof(msgbuf));
memcpy(msgbuf,msgp,sizeof(msgp)); 
send(connfd,msgbuf,sizeof(msgbuf),0);


//printf("this is after listen and before accept\n");



lisfd = accept(sock_fd, (struct sockaddr *)NULL, NULL);

  if (lisfd == -1) {
    perror("accpet error");
    exit(1);
  }
//printf("this is after accept\n");

 p=mp+2;
  // the party 2 will try to connect party 1.
  char * servInetAddr2 = p->memberadd;
  //printf("this is servInetAddr2: %s \n", servInetAddr2);
  int servPort2 = LIS_PORT2;
  //socklen_t socklen = sizeof(struct sockaddr_in);
  //int connfd;
  struct sockaddr_in servaddr2, claddr2;
  connfd2 = socket(AF_INET, SOCK_STREAM, 0);
  // FD_ZERO(rset);

  bzero(&claddr2, sizeof(claddr2));
  claddr2.sin_family = AF_INET;
  claddr2.sin_addr.s_addr = htonl(INADDR_ANY);
  claddr2.sin_port = htons(LOC_PORT);
if (setsockopt(connfd2, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");
  bind(connfd2, (struct sockaddr*)&claddr2, socklen);
  bzero(&servaddr2, sizeof(servaddr2));
  servaddr2.sin_family = AF_INET;
  servaddr2.sin_port = htons(servPort2);
  inet_pton(AF_INET, servInetAddr2, &servaddr2.sin_addr);
  if (connect(connfd2, (struct sockaddr *) &servaddr2, sizeof(servaddr2)) < 0) {
    perror("connect error");
  }

  //p->keepfd=connfd2;

//printf("this is after connect with 1\n");




  //int flags  = fcntl(lisfd,F_GETFL,0);       
  //fcntl(lisfd,F_SETFL,flags&~O_NONBLOCK);    

  //memset(msgbuf,0,sizeof(msgbuf));
  //recv(lisfd,msgbuf,sizeof(*msgp),0 );
  //memset(msgp,0,sizeof(*msgp));
  //memcpy(msgp,msgbuf,sizeof(*msgp));

  //if (msgp->stats != 2)  //2 means the accepted party is 2.
  //{
  //perror("recv error");
  //exit(1);
  //}

  //p=mp+2;
  //p->keepfd=lisfd;
  //party 3 needs to tell party 1 that party 2 is online now.
  //memset(msgp,0,sizeof(*msgp));
  //msgp->stats=10;    
  //memset(msgbuf,0,sizeof(msgbuf));
  //memcpy(msgbuf,msgp,sizeof(*msgp)); 
  //send(connfd,msgbuf,sizeof(*msgp),0);
/*
p=mp+1;
if(close(p->keepfd)<0)
{
    perror("close error");
    exit(1);
}
p++;
if(close(p->keepfd)<0)
{
    perror("close error");
    exit(1);
}
*/
  neighfd[1]= connfd; //2->3
  neighfd[2]= lisfd; //2<-1
  neighfd[3]= connfd2;//2->1
  neighfd[4]= lisfd2;//2<-3

  memset(msgp,0,sizeof(*msgp));
  msgp->stats=23;    
  memset(msgbuf,0,sizeof(msgbuf));
  memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[1],msgbuf,sizeof(*msgp),0);

  memset(msgp,0,sizeof(*msgp));
  msgp->stats=21;    
  memset(msgbuf,0,sizeof(msgbuf));
  memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[3],msgbuf,sizeof(*msgp),0);

  memset(msgbuf,0,sizeof(msgbuf));
  recv(neighfd[2],msgbuf,sizeof(*msgp),0 );
  memset(msgp,0,sizeof(*msgp));
  memcpy(msgp,msgbuf,sizeof(*msgp));
  printf("1.received(1):%d\n",msgp->stats);

  memset(msgbuf,0,sizeof(msgbuf));
  recv(neighfd[4],msgbuf,sizeof(*msgp),0 );
  memset(msgp,0,sizeof(*msgp));
  memcpy(msgp,msgbuf,sizeof(*msgp));
  printf("2.received(3):%d\n",msgp->stats);
}

void setconnect_c(struct memberlist *mp, struct message *msgp, int *neighfd)
{
  struct memberlist *p;

  int connfd, lisfd, sock_fd, connfd2, lisfd2, sock_fd2;
  p=mp;
  p++;
  char msgbuf[sizeof(struct message)];


  // the party 3 will try to connect party 1 at first.
  char * servInetAddr = p->memberadd;
  //printf("this is servInetAddr: %s \n", servInetAddr);
  int servPort = LIS_PORT;
  socklen_t socklen = sizeof(struct sockaddr_in);
  //int connfd;
  struct sockaddr_in servaddr, claddr;
  connfd = socket(AF_INET, SOCK_STREAM, 0);
  // FD_ZERO(rset);

  bzero(&claddr, sizeof(claddr));
  claddr.sin_family = AF_INET;
  claddr.sin_addr.s_addr = htonl(INADDR_ANY);
  claddr.sin_port = htons(LOC_PORT);
int enable = 1;
if (setsockopt(connfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");
  bind(connfd, (struct sockaddr*)&claddr, socklen);
  bzero(&servaddr, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_port = htons(servPort);
  inet_pton(AF_INET, servInetAddr, &servaddr.sin_addr);
  if (connect(connfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
    perror("connect error");
  }

  p->keepfd=connfd;
  //then party 3 wait for the party 1
  struct sockaddr_in server_addr2;

  if ((sock_fd2 = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("listen error");
  }





  bzero(&server_addr2, sizeof(struct sockaddr_in));
  server_addr2.sin_family = AF_INET;
  server_addr2.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr2.sin_port = htons(LIS_PORT2);

if (setsockopt(sock_fd2, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");//////
  if (bind(sock_fd2, (struct sockaddr *)(&server_addr2), sizeof(struct sockaddr)) == -1) {
    perror("bind 1 error");
  }
	printf("this is after bind \n");
  //int listen_flag = 0;

  if(listen(sock_fd2, 2) == -1) {
    perror("listen error");
    exit(1);
  }

  if ((lisfd2 = accept(sock_fd2, (struct sockaddr *)NULL, NULL)) == -1) {
    perror("accpet error");
    exit(1);
  }
//printf("this is after accept the 1\n");



  //then party 3 wait for the party 2
  struct sockaddr_in server_addr;

  if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("listen error");
  }




  bzero(&server_addr, sizeof(struct sockaddr_in));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr.sin_port = htons(LIS_PORT);

if (setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");//////
  if (bind(sock_fd, (struct sockaddr *)(&server_addr), sizeof(struct sockaddr)) == -1) {
    perror("bind 2 error");
  }
  //int listen_flag = 0;

  if(listen(sock_fd, 2) == -1) {
    perror("listen error");
    exit(1);
  }

  if ((lisfd = accept(sock_fd, (struct sockaddr *)NULL, NULL)) == -1) {
    perror("accpet error");
    exit(1);
  }
//printf("this is after acceot\n");
  //int flags  = fcntl(lisfd,F_GETFL,0);       
  //fcntl(lisfd,F_SETFL,flags&~O_NONBLOCK);    


  p=mp+2;
  p->keepfd=lisfd;

  // the party 3 will try to connect party 2.
  char * servInetAddr2 = p->memberadd;
  //printf("this is servInetAddr: %s \n", servInetAddr);
  int servPort2 = LIS_PORT2;
  //socklen_t socklen = sizeof(struct sockaddr_in);
  //int connfd;
  struct sockaddr_in servaddr2, claddr2;
  connfd2 = socket(AF_INET, SOCK_STREAM, 0);
  // FD_ZERO(rset);

  bzero(&claddr2, sizeof(claddr2));
  claddr2.sin_family = AF_INET;
  claddr2.sin_addr.s_addr = htonl(INADDR_ANY);
  claddr2.sin_port = htons(LOC_PORT2);
if (setsockopt(connfd2, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");
  bind(connfd2, (struct sockaddr*)&claddr2, socklen);
  bzero(&servaddr2, sizeof(servaddr2));
  servaddr2.sin_family = AF_INET;
  servaddr2.sin_port = htons(servPort2);
  inet_pton(AF_INET, servInetAddr2, &servaddr2.sin_addr);
  if (connect(connfd2, (struct sockaddr *) &servaddr2, sizeof(servaddr2)) < 0) {
    perror("connect error");
  }

  p->keepfd=connfd2;

  memset(msgbuf,0,sizeof(msgbuf));
  recv(lisfd,msgbuf,sizeof(*msgp),0 );
  memset(msgp,0,sizeof(*msgp));
  memcpy(msgp,msgbuf,sizeof(*msgp));

  if (msgp->stats != 2)  //2 means the accepted party is 2.
    {
      perror("recv error");
      exit(1);
    }
//printf("this is after recving a message from 2\n");

  //party 3 needs to tell party 1 that party 2 is online now.
  memset(msgp,0,sizeof(*msgp));
  msgp->stats=10;    
  memset(msgbuf,0,sizeof(msgbuf));
  memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(connfd,msgbuf,sizeof(*msgp),0);

/*
p=mp+1;
if(close(p->keepfd)<0)
{
    perror("close error");
    exit(1);
}
p++;
if(close(p->keepfd)<0)
{
    perror("close error");
    exit(1);
}
*/
  neighfd[1]= connfd; //3->1
  neighfd[2]= lisfd;  //3<-2
  neighfd[3]= connfd2;//3->2
  neighfd[4]= lisfd2; //3<-1

  memset(msgp,0,sizeof(*msgp));
  msgp->stats=31;    
  memset(msgbuf,0,sizeof(msgbuf));
  memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[1],msgbuf,sizeof(*msgp),0);

  memset(msgp,0,sizeof(*msgp));
  msgp->stats=32;    
  memset(msgbuf,0,sizeof(msgbuf));
  memcpy(msgbuf,msgp,sizeof(*msgp)); 
  send(neighfd[3],msgbuf,sizeof(*msgp),0);

  memset(msgbuf,0,sizeof(msgbuf));
  recv(neighfd[2],msgbuf,sizeof(*msgp),0 );
  memset(msgp,0,sizeof(*msgp));
  memcpy(msgp,msgbuf,sizeof(*msgp));
  printf("1.received(2):%d\n",msgp->stats);

  memset(msgbuf,0,sizeof(msgbuf));
  recv(neighfd[4],msgbuf,sizeof(*msgp),0 );
  memset(msgp,0,sizeof(*msgp));
  memcpy(msgp,msgbuf,sizeof(*msgp));
  printf("2.received(1):%d\n",msgp->stats);
}

