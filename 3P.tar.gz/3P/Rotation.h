#ifndef Rotation
#define Rotation
#define BitBase 128
void mpzout(mpz_t * op, int num);
void clear_one (int num, mpz_t * op);
void rotation(mpz_t * op, mpz_t * op2, int num, int offset);
void conver_MtoB(mpz_t * op,int num, uint8_t * buffer, int offset);
void conver_BtoM(mpz_t * op,int num, uint8_t * buffer);
void SplitArray(mpz_t * op, mpz_t * op2, int num, gmp_randstate_t state, mpz_t d);
void CombineArray(mpz_t * op, mpz_t * op2, mpz_t * op3, int num, int offset, mpz_t d);
#endif
