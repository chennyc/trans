# paillier encryption
from paillier.paillier import *
from load_key import load_key


# Import socket module
import socket               
 
# Create a socket object
s = socket.socket()         
 
# Define the port on which you want to connect
port = 12345               
 
# connect to the server on local computer
s.connect(('127.0.0.1', port))

# load key
priv = load_key('priv')
pub = load_key()

while True:
 
    # receive command from the server
    print s.recv(1024)
    
    # input the number
    x = input()
    cx = encrypt(pub, x)
    s.send(str(cx))
    
    # output result
    cr = s.recv(1024)
    print decrypt(priv, pub, long(cr))
    
    # close the connection
    s.close()
    break
