def main():
    
    # first of all import the socket library
    import socket 
    import sys, select

                 
 
    # next create a socket object
    s = socket.socket()
         
    print "Socket successfully created"
 
    port = 12345              
 
    # Next bind to the port
    # we have not typed any ip in the ip field
    # instead we have inputted an empty string
    # this makes the server listen to requests 
    # coming from other computers on the network
    s.bind(('', port))        
    print "socket binded to %s" %(port)
 
    # put the socket into listening mode
    s.listen(5)     
    print "socket is listening"           

    


    client_list = []
    addr_list = []
    result = -1

    
    while True:
        # Establish connection with client.
        try:
            s.settimeout(0.5) 
            c, addr = s.accept()
        
            print 'Got connection from', addr

            client_list.append(c)
            addr_list.append(addr)

            print 'Currently connected clients  ', addr_list

            
            
        except socket.timeout:
            print 'Next round'
            pass
            
        except:
            raise
            
            
        ##
            
        try:
            keyinput = 'None'
            print 'What do you want to do: '
            ready, _, __ = select.select([sys.stdin], [],[], 10)
            
            if (ready):
                keyinput = sys.stdin.readline().strip()
                print keyinput
            else:
                pass
            
            if keyinput == 'plus':
                for c in client_list:
                    c.send('pls send me a number:')
                    cx = c.recv(1024)
                    
                    if result == -1:
                        result = long(cx)
                    else:
                        result = e_add(pub, result, long(cx))
            
                    print 'encrypted:  ', result

                for c in client_list:
                    c.send(str(result))
                break
                        
                        
        except socket.timeout:
            pass
            
        except:
            raise

            
 
            
            
if __name__ == '__main__':
    from paillier.paillier import *
    from load_key import load_key
    pub = load_key()
    main()

   
        
    

