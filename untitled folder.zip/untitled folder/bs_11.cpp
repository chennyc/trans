/* File generated from [BS/BS.c] by PICCO Thu Apr 16 13:36:05 2020
 */

#include <limits.h>

#include <float.h>

//extern void *memcpy(void*,const void*,unsigned int);

//# 1 "ort.onoff.defs"

extern  "C" int   ort_initialize(int*, char***);
 extern "C" void  ort_finalize(int);


/* File generated from [BS/BS.c] by PICCO Thu Apr 16 13:36:05 2020
 */

#include "smc-compute/SMC_Utils.h"

#include <gmp.h>

#include <omp.h>


SMC_Utils *__s;



int  __original_main(int _argc_ignored, char **_argv_ignored)
{
  
  mpz_t _picco_tmp1;
  mpz_init(_picco_tmp1);

  mpz_t* _picco_ftmp1 = (mpz_t*)malloc(sizeof(mpz_t) * 4);
  for(int _picco_j = 0; _picco_j < 4; _picco_j++)
    mpz_init(_picco_ftmp1[_picco_j]);
  void* _picco_temp_;
 int K = 2048;

  int i, j, k;

  mpz_t* L; 
  L = (mpz_t*)malloc(sizeof(mpz_t) * (K));
  for (int _picco_i = 0; _picco_i < K; _picco_i++)
        mpz_init(L[_picco_i]);

  mpz_t* C; 
  C = (mpz_t*)malloc(sizeof(mpz_t) * (K));
  for (int _picco_i = 0; _picco_i < K; _picco_i++)
        mpz_init(C[_picco_i]);

  mpz_t* C_1; 
  C_1 = (mpz_t*)malloc(sizeof(mpz_t) * (K));
  for (int _picco_i = 0; _picco_i < K; _picco_i++)
        mpz_init(C_1[_picco_i]);

  mpz_t* D; 
  D = (mpz_t*)malloc(sizeof(mpz_t) * (K));
  for (int _picco_i = 0; _picco_i < K; _picco_i++)
        mpz_init(D[_picco_i]);

  mpz_t* B; 
  B = (mpz_t*)malloc(sizeof(mpz_t) * (K));
  for (int _picco_i = 0; _picco_i < K; _picco_i++)
        mpz_init(B[_picco_i]);

  mpz_t z;
  mpz_init(z);

  mpz_t b;
  mpz_init(b);

  __s->smc_input(1, L, K, "int", -1);

  __s->smc_input(1, &b, "int", -1);

  i = 0;
  for ( ;i < K; )
  {
    {
            __s->smc_set(b, B[i], 32, 32, "int", -1);
    }
    i++;
  }

  int it = 0;
  for(;it<100;){

printf("%d th start\n",it);
  __s->smc_leq(B, L, 32, 32, C, 1, K, "int", -1);

    __s->smc_set(C[0], C_1[0], 1, 1, "int", -1);

  i = 1;
  for ( ;i < K; )
  {
    {
      __s->smc_sub(1, C[i - 1], _picco_tmp1, -1, 1, 1, "int", -1);
      __s->smc_set(_picco_tmp1, C_1[i], 1, 1, "int", -1);
    }
    i++;
  }

  __s->smc_mult(C, C_1, 1, 1, D, 1, K, "int", -1);

    __s->smc_set(C[0], D[0], 1, 1, "int", -1);

  __s->smc_sub(1, C[K - 2], _picco_tmp1, -1, 1, 1, "int", -1);
  __s->smc_set(_picco_tmp1, D[K - 1], 1, 1, "int", -1);

  __s->smc_dot(L, D, K, z, -1);
  it++;
  }
  __s->smc_output(1, &z, "int", -1);
}


/* smc-compiler generated main() */
int main(int argc, char **argv)
{

 if(argc < 8){
fprintf(stderr,"Incorrect input parameters\n");
fprintf(stderr,"Usage: <id> <runtime-config> <privatekey-filename> <number-of-input-parties> <number-of-output-parties> <input-share> <output>\n");
exit(1);
}

 std::string IO_files[atoi(argv[4]) + atoi(argv[5])];
for(int i = 0; i < argc-6; i++)
   IO_files[i] = argv[6+i];

__s = new SMC_Utils(atoi(argv[1]), argv[2], argv[3], atoi(argv[4]), atoi(argv[5]), IO_files, 3, 1, 33, "4294967311", 1);

struct timeval tv1;
struct timeval tv2;  int _xval = 0;

  gettimeofday(&tv1,NULL);
  _xval = (int) __original_main(argc, argv);
  gettimeofday(&tv2, NULL);
  std::cout << "Time: " << __s->time_diff(&tv1,&tv2) << std::endl;
  return (_xval);
}

